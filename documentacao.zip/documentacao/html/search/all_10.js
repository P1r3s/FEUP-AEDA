var searchData=
[
  ['utente',['Utente',['../class_utente.html',1,'Utente'],['../class_utente.html#a8ba52beed4f3294ac24a7ac5afbb3a65',1,'Utente::Utente()']]],
  ['utentenaoexiste',['UtenteNaoExiste',['../class_utente_nao_existe.html',1,'UtenteNaoExiste'],['../class_utente_nao_existe.html#ac7a64cfeac93e23a29fe0679129694be',1,'UtenteNaoExiste::UtenteNaoExiste()']]]
];
