var searchData=
[
  ['what',['what',['../class_utente_nao_existe.html#a1557e856cd3b83fbcd5b7a6a86b254dc',1,'UtenteNaoExiste::what()'],['../class_prof_nao_existe.html#ad5f29968f3524510b7e3d0e55d928e89',1,'ProfNaoExiste::what()'],['../class_tecnico_nao_existe.html#a6927ed7d2156ce8f5debfe3342b1db43',1,'TecnicoNaoExiste::what()']]]
];
