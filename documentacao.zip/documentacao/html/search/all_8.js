var searchData=
[
  ['livre',['Livre',['../class_livre.html',1,'Livre'],['../class_livre.html#a66c4f682dc8b5b1c220b3affa6499af4',1,'Livre::Livre()']]]
];
