var searchData=
[
  ['lerficheiroaulas',['lerficheiroAulas',['../_funcoes_8cpp.html#abc29ff8b237adfa9d4f3fc808b0b6226',1,'lerficheiroAulas(CampoTenis *c):&#160;Funcoes.cpp'],['../_funcoes_8h.html#abc29ff8b237adfa9d4f3fc808b0b6226',1,'lerficheiroAulas(CampoTenis *c):&#160;Funcoes.cpp']]],
  ['lerficheirolivres',['lerficheiroLivres',['../_funcoes_8cpp.html#a5adfa1b210ebce3ae07afa73decc5535',1,'lerficheiroLivres(CampoTenis *c):&#160;Funcoes.cpp'],['../_funcoes_8h.html#a5adfa1b210ebce3ae07afa73decc5535',1,'lerficheiroLivres(CampoTenis *c):&#160;Funcoes.cpp']]],
  ['lerficheiroprofessores',['lerficheiroProfessores',['../_funcoes_8cpp.html#ab4fea244d5ceb3f8459ffcfcb2ee9eca',1,'lerficheiroProfessores(CampoTenis *c):&#160;Funcoes.cpp'],['../_funcoes_8h.html#ab4fea244d5ceb3f8459ffcfcb2ee9eca',1,'lerficheiroProfessores(CampoTenis *c):&#160;Funcoes.cpp']]],
  ['lerficheiroutentes',['lerficheiroUtentes',['../_funcoes_8cpp.html#ae9c9df5d16e185af0af5a6ea67ca8cd6',1,'lerficheiroUtentes(CampoTenis *c):&#160;Funcoes.cpp'],['../_funcoes_8h.html#ae9c9df5d16e185af0af5a6ea67ca8cd6',1,'lerficheiroUtentes(CampoTenis *c):&#160;Funcoes.cpp']]],
  ['livre',['Livre',['../class_livre.html',1,'Livre'],['../class_livre.html#a66c4f682dc8b5b1c220b3affa6499af4',1,'Livre::Livre()']]],
  ['livresdoutente',['livresDoUtente',['../class_utente.html#a9aee23b558a79171e560383b742c3071',1,'Utente']]]
];
