var searchData=
[
  ['minutes',['minutes',['../class_campo_tenis.html#a7a3188cee844f277ec53da715a60234f',1,'CampoTenis']]],
  ['modos',['Modos',['../class_modos.html',1,'Modos'],['../class_modos.html#a037c8b353f7b8c6d1679f9bf591ee52e',1,'Modos::Modos()']]]
];
