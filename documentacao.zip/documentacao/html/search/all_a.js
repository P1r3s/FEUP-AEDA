var searchData=
[
  ['nome',['nome',['../class_pessoa.html#ad4e88b8f3499405a7a03df648857c338',1,'Pessoa']]],
  ['nummaximoutentesporcampo',['NumMaximoUtentesPorCampo',['../class_campo_tenis.html#a4e7599fcad90036f0f8ce3dd4a7b0ccf',1,'CampoTenis']]]
];
