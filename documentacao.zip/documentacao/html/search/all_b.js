var searchData=
[
  ['operator_3c',['operator&lt;',['../class_utente.html#a2417d11e64467e99daa4a54e096b9acd',1,'Utente::operator&lt;()'],['../class_servico_tecnico.html#a01860d8f786a23f8d42ec006817de03b',1,'ServicoTecnico::operator&lt;()']]]
];
