var searchData=
[
  ['removeprof',['removeProf',['../class_campo_tenis.html#a29fe5ed8c34fa351e09819ad2f320002',1,'CampoTenis']]],
  ['removetec',['removeTec',['../class_campo_tenis.html#a05d875d46f59adf643716eaa3fabfac0',1,'CampoTenis']]],
  ['removeutente',['removeUtente',['../class_campo_tenis.html#a88c21484a0f3add85494e536cbb484ad',1,'CampoTenis']]],
  ['returnsigla',['returnSigla',['../class_campo_tenis.html#aac17109204de6a8892a695bfcc6e43db',1,'CampoTenis']]]
];
