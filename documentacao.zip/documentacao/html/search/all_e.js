var searchData=
[
  ['servicotecnico',['ServicoTecnico',['../class_servico_tecnico.html',1,'ServicoTecnico'],['../class_servico_tecnico.html#a8df4804061443067235e27877d8b390a',1,'ServicoTecnico::ServicoTecnico()']]]
];
