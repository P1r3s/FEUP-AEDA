var searchData=
[
  ['invalidslot',['InvalidSlot',['../class_invalid_slot.html',1,'']]]
];
