var searchData=
[
  ['modos',['Modos',['../class_modos.html',1,'']]]
];
