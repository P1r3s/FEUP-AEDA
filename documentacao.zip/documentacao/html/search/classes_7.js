var searchData=
[
  ['utente',['Utente',['../class_utente.html',1,'']]]
];
