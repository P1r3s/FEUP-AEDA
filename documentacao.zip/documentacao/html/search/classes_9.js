var searchData=
[
  ['utente',['Utente',['../class_utente.html',1,'']]],
  ['utentenaoexiste',['UtenteNaoExiste',['../class_utente_nao_existe.html',1,'']]]
];
