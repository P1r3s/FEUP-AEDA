var searchData=
[
  ['addaula',['addAula',['../class_campo_tenis.html#abc664d504ef29fe52e78c717c37e01de',1,'CampoTenis']]],
  ['addaulautente',['addAulaUtente',['../class_campo_tenis.html#aa794df2515d545bf11b43351c00df27a',1,'CampoTenis']]],
  ['addlivre',['addLivre',['../class_campo_tenis.html#a7e9b32fd03b3bac44fd4f96f3e6d0014',1,'CampoTenis']]],
  ['addlivreutente',['addLivreUtente',['../class_campo_tenis.html#aed1807deec9db3254d2f64d4d8e19b8f',1,'CampoTenis']]],
  ['addprof',['addProf',['../class_campo_tenis.html#a64d9bf218ad4ba1387e5582714d6be9e',1,'CampoTenis']]],
  ['addutente',['addUtente',['../class_campo_tenis.html#ae5762d5dda1b24888bd7e626f6009889',1,'CampoTenis']]],
  ['adicionarprofessor',['adicionarProfessor',['../_funcoes_8cpp.html#a1e8fedf1af60ee6a2604630d599d9537',1,'adicionarProfessor(string nome, string sigla, int idade):&#160;Funcoes.cpp'],['../_funcoes_8h.html#a1e8fedf1af60ee6a2604630d599d9537',1,'adicionarProfessor(string nome, string sigla, int idade):&#160;Funcoes.cpp']]],
  ['adicionarutente',['adicionarUtente',['../_funcoes_8cpp.html#a7d6942bad8ef7a0bcde5480f26c2626c',1,'adicionarUtente(string no, int idade, int gold):&#160;Funcoes.cpp'],['../_funcoes_8h.html#a7d6942bad8ef7a0bcde5480f26c2626c',1,'adicionarUtente(string no, int idade, int gold):&#160;Funcoes.cpp']]],
  ['atualizavetordisp',['atualizaVetorDisp',['../class_campo_tenis.html#a176ec4b54d91692c0fe50d2eeff64958',1,'CampoTenis']]],
  ['aula',['Aula',['../class_aula.html#a57a0d46cab6babaf084e6f9da2acdbcd',1,'Aula']]]
];
