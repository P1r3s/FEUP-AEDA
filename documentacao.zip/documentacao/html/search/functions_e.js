var searchData=
[
  ['tecdisp',['tecDisp',['../class_campo_tenis.html#aa7cefcc2b41e98e2c4a46fe9200c19d6',1,'CampoTenis']]],
  ['tecniconaoexiste',['TecnicoNaoExiste',['../class_tecnico_nao_existe.html#af668a9a44db1cfbff3605d37bfc84a89',1,'TecnicoNaoExiste']]]
];
