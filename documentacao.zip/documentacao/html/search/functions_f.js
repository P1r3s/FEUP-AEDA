var searchData=
[
  ['utente',['Utente',['../class_utente.html#a0daa264aade1af3665547390da977aa5',1,'Utente']]]
];
