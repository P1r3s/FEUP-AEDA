var searchData=
[
  ['aulasdoprofessor',['aulasDoProfessor',['../class_professor.html#aff62f9754227538e5904c0820cef1f4f',1,'Professor']]],
  ['aulasdoutente',['aulasDoUtente',['../class_utente.html#a2a1f0b3763c0aa3909d074d30b0f08af',1,'Utente']]]
];
