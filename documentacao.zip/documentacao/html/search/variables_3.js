var searchData=
[
  ['goldcard',['goldCard',['../class_utente.html#a83ad543eb4fd14194b65b482a686db39',1,'Utente']]]
];
