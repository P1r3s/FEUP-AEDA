var searchData=
[
  ['horainicio',['horaInicio',['../class_modos.html#a0a548562f3c31031bd849b19b5bab542',1,'Modos']]]
];
