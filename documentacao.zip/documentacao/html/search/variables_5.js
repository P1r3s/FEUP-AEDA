var searchData=
[
  ['idade',['idade',['../class_pessoa.html#abe9003d01579f42f07b56ea2c9728acb',1,'Pessoa']]]
];
