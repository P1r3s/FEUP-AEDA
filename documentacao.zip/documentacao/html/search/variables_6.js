var searchData=
[
  ['livresdoutente',['livresDoUtente',['../class_utente.html#a9aee23b558a79171e560383b742c3071',1,'Utente']]]
];
